import appRoutes from "./routes";

export {
  appRoutes
}
