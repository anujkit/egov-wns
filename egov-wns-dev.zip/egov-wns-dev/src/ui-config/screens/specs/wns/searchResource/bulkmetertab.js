import { getCommonContainer } from "egov-ui-framework/ui-config/screens/specs/utils";
import { wnsApplication } from './bulkmeterEmpa';
import { searchApplications } from './bulkMeterSearcha';

export const showSearches = getCommonContainer({
  showSearchScreens: {
    uiFramework: "custom-containers-local",
    moduleName: "egov-wns",
    componentPath: "CustomTabContainer",
    props: {
      tabs: [
        {
          tabButton: { labelName: "SEARCH CONNECTIONS", labelKey: "WS_SEARCH_CONNECTIONS" },
          tabContent: { wnsApplication }
        },
        {
          tabButton: { labelName: "Genrate Bill", labelKey: "Genrate Bill" },
          tabContent: { searchApplications }
        }
      ],
      tabIndex : 0
    },
    type: "array"
  }
});
