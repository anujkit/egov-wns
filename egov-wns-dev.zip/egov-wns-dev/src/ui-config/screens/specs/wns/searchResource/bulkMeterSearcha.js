import {
    getCommonCard,
    getCommonTitle,
    getTextField,
    getSelectField,
    getCommonContainer,
    getCommonParagraph,
    getPattern,
    getDateField,
    getLabel
  } from "egov-ui-framework/ui-config/screens/specs/utils";
  import { searchApiCall, exceldatadownload } from "./bulkmeterfun";
  import { resetFieldsForApplication } from '../../utils';
  import {
    handleScreenConfigurationFieldChange as handleField,
    prepareFinalObject
  } from "egov-ui-framework/ui-redux/screen-configuration/actions";
  import get from 'lodash/get';
  


  
  function fileupload(){
   
  }

  export const documentList = {
    
    uiFramework: "custom-containers-local",
    moduleName: "egov-wns",
    componentPath: "DocumentListContainer",
    props: {
      buttonLabel: {
        labelName: "UPLOAD FILE",
        labelKey: "TL_BUTTON_UPLOAD FILE"
      },
      inputProps : [
        {
          type : "OWNERIDPROOF",
          description: {
            labelName: "Only .jpg and .pdf files. 6MB max file size.",
            labelKey: "TL_UPLOAD_RESTRICTIONS"
          },
          formatProps :{
            accept : "image/*, .pdf, .png, .jpeg",
          }, 
          maxFileSize: 5000
        }
      ],
        
    }
  };
  
  export const searchApplications = getCommonCard({
    subHeader: getCommonTitle({
      labelKey: "Genrate Bill"
    }),
    subParagraph: getCommonParagraph({
      labelKey: "Please uploade excel file"
    }),
    
   
  
    button: getCommonContainer({
      searchButton: {
        componentPath: "Button",
        gridDefination: {
          xs: 12,
          sm: 6,
          // align: "center"
        },
        props: {
          variant: "contained",
          style: {
            color: "white",
            margin: "8px",
            backgroundColor: "rgba(0, 0, 0, 0.6000000238418579)",
            borderRadius: "2px",
            width: "220px",
            height: "48px"
          }
        },
        children: {
          buttonLabel: getLabel({
            labelKey: "WS_SEARCH_CONNECTION_SEARCH_BUTTON"
          })
        },
        onClickDefination: {
          action: "condition",
         // callBack: searchdataBulk
        }
      },
      searchButtonnew: {
        componentPath: "Button",
        gridDefination: {
          xs: 12,
          sm: 6,
          // align: "center"
        },
        props: {
          variant: "contained",
          style: {
            color: "white",
            margin: "8px",
            backgroundColor: "rgba(0, 0, 0, 0.6000000238418579)",
            borderRadius: "2px",
            width: "220px",
            height: "48px"
          }
        },
        inputProps : [
                  {
                    type : "OWNERIDPROOF",
                    description: {
                      labelName: "Only .jpg and .pdf files. 6MB max file size.",
                      labelKey: "TL_UPLOAD_RESTRICTIONS"
                    },
                    formatProps :{
                      accept : "image/*, .pdf, .png, .jpeg",
                    }, 
                    maxFileSize: 5000
                  }
                 ],
        children: {
          buttonLabel: getLabel({
            labelKey: "Upload Excel"
          })
        },
        onClickDefination: {
          action: "condition",
        callBack: fileupload
        }
      },
      
      //  searchButton: {
      // //   uiFramework: "custom-containers-local",
      // // moduleName: "egov-wns",
      // // componentPath: "DocumentListContainer",
      //     componentPath: "Button",
      //     gridDefination: { xs: 12, sm: 6 },
      //     props: {
      //       buttonLabel: {
      //         labelName: "UPLOAD FILE",
      //         labelKey: "UPLOAD FILEE"
      //       },
      //       inputProps : [
      //         {
      //           type : "OWNERIDPROOF",
      //           description: {
      //             labelName: "Only .jpg and .pdf files. 6MB max file size.",
      //             labelKey: "TL_UPLOAD_RESTRICTIONS"
      //           },
      //           formatProps :{
      //             accept : "image/*, .pdf, .png, .jpeg",
      //           }, 
      //           maxFileSize: 5000
      //         }
      //       ],
      //     }
              
      //   },
        
  
     
    })
  });
  
  