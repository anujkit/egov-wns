import React from "react";
import { sortByEpoch, getEpochForDate } from "../../utils";
import './index.css'
import LabelContainer from "egov-ui-framework/ui-containers/LabelContainer";
import {
  getCommonCard,
  getCommonTitle,
  getTextField,
  getSelectField,
  getCommonContainer,
  getCommonParagraph,
  getPattern,
  getLabel
} from "egov-ui-framework/ui-config/screens/specs/utils";
import { setRoute } from "egov-ui-framework/ui-redux/app/actions";
import store from "ui-redux/store";
import { httpRequest } from "../../../../../ui-utils";
import get from "lodash/get";
import { getUserInfo, getTenantIdCommon, getTenantId } from "egov-ui-kit/utils/localStorageUtils";
import * as XLSX from "xlsx/dist/xlsx.full.min.js";
let exceldata=[];
let searchdata=[];
let myxceldata;
let dataa;
export const searchdataBulk = async (state, dispatch) =>{
debugger;
let getCurrentlocality = get(state.screenConfiguration.preparedFinalObject.searchConnection, "locality");
alert("testing");
debugger;
let requestdata= [ { key: "tenantId", value: getTenantId() },
{ key: "locality", value:getCurrentlocality } ,
{ key: "connectionType", value:"Metered" }
];
  try {
    //https://mseva-uat.lgpunjab.gov.in/ws-services/wc/_search?searchType=CONNECTION&tenantId=pb.nangal&locality=NGL31&connectionType=Metered
    //Read metered & non-metered demand expiry date and assign value.
    searchdata = await httpRequest("post", "/ws-services/wc/_search", "_search", requestdata);        
    console.log(searchdata.WaterConnection);
    myxceldata =searchdata.WaterConnection;
    dataa = searchdata.WaterConnection;
  } 
  catch (err) { console.log(err) }
 }
 export const ExcelExport = ( ) => {
  alert("testing");
  debugger;
 
 var SheetWS = XLSX.utils.json_to_sheet(myxceldata);
    // A workbook is the name given to an Excel file
    var wb = XLSX.utils.book_new() // make Workbook of Excel
    // add Worksheet to Workbook
    // Workbook contains one or more worksheets
    XLSX.utils.book_append_sheet(wb, SheetWS, 'Sheet1') // sheetAName is name of Worksheet
    // export Excel file
    XLSX.writeFile(wb, `abcd.xlsx`)
};
export const searchResults = {
  uiFramework: "custom-molecules",
  moduleName: "egov-wns",
  componentPath: "Table",
  visible: true,
  props: {
    columns: [
      {
        name: "Service",
        labelKey: "WS_COMMON_TABLE_COL_SERVICE_LABEL", 
        options: {
          filter: false,
          customBodyRender: value => (
            <span style={{ color: '#000000' }}>
              {value}
            </span>
          )
        }
      },
      {
        name: "Consumer No",
        labelKey: "WS_COMMON_TABLE_COL_CONSUMER_NO_LABEL", 
        options: {
          filter: false,
          customBodyRender: (value, index) => (
            <div className="linkStyle" onClick={() => getConnectionDetails(index)}>
              <a>{value}</a>
            </div>
          )
        }
      },
      {name : "Owner Name",labelKey: "WS_COMMON_TABLE_COL_OWN_NAME_LABEL" },
      {name : "Status",labelKey: "WS_COMMON_TABLE_COL_STATUS_LABEL" },
      {name : "Due",labelKey: "WS_COMMON_TABLE_COL_DUE_LABEL" },
      {name : "Address",labelKey: "WS_COMMON_TABLE_COL_ADDRESS" },
      {name : "Due Date",labelKey: "WS_COMMON_TABLE_COL_DUE_DATE_LABEL" },
      {
        name: "Action",
        labelKey: "WS_COMMON_TABLE_COL_ACTION_LABEL",
        options: {
          filter: false,
          customBodyRender: (value, dataa) => {
            debugger;
            {
              return (
                <div className="linkStyle" onClick={() => getViewBillDetails(dataa)} style={{ color: '#fe7a51', textTransform: 'uppercase' }}>
                  <LabelContainer
                    labelKey="WS_COMMON_COLLECT_LABEL"
                    style={{
                      color: "#fe7a51",
                      fontSize: 14,
                    }}
                  />
                </div>
              )
            }
           
          }
        }
      },
      {
        name: "tenantId",
        labelKey: "WS_COMMON_TABLE_COL_TENANTID_LABEL",
        options: {
          display: false
        }
      },
      {
        name: "connectionType",
        labelKey: "WS_COMMON_TABLE_COL_CONNECTIONTYPE_LABEL",
        options: {
          display: false
        }
      }
    ],
    title: {labelKey:"WS_HOME_SEARCH_RESULTS_TABLE_HEADING", labelName:"Search Results for Water & Sewerage Connections"},
    options: {
      filter: false,
      download: false,
      responsive: "stacked",
      selectableRows: false,
      hover: true,
      rowsPerPageOptions: [10, 15, 20]
    },
    customSortColumn: {
      column: "Application Date",
      sortingFn: (dataa, i, sortDateOrder) => {
        const epochDates = dataa.reduce((acc, curr) => {
          acc.push([...curr, getEpochForDate(curr[4], "dayend")]);
          return acc;
        }, []);
        const order = sortDateOrder === "asc" ? true : false;
        const finalData = sortByEpoch(epochDates, !order).map(item => {
          item.pop();
          return item;
        });
        return { dataa: finalData, currentOrder: !order ? "asc" : "desc" };
      }
    }
  }
};

const getConnectionDetails = data => {
  store.dispatch(
    setRoute(`connection-details?connectionNumber=${data.rowData[1]}&tenantId=${data.rowData[8]}&service=${data.rowData[0]}&connectionType=${data.rowData[9]}&due=${data.rowData[4]}`)
  )
}

const getViewBillDetails = data => {
  store.dispatch(
    setRoute( `viewBill?connectionNumber=${data.rowData[1]}&tenantId=${data.rowData[8]}&service=${data.rowData[0]}&connectionType=${data.rowData[9]}`)
  )
}