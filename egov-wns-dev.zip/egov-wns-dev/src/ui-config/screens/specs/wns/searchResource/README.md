To hide 'NEW APPLICATION' button pass 'hasButton=false' in URL parameters

To hide 'Pending for your Approval' box pass 'hasApproval=false' in URL parameters
