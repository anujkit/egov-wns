import {
  getCommonCard,
  getCommonTitle,
  getSelectField,
  getCommonContainer,
  getLabel
} from "egov-ui-framework/ui-config/screens/specs/utils";
import {generateBillApiCall ,searchBillApiCall} from "../generateBillResource/functions"
import "./index.css";
import {
  handleScreenConfigurationFieldChange as handleField,
  prepareFinalObject
} from "egov-ui-framework/ui-redux/screen-configuration/actions";
import { httpRequest } from "../../../../../ui-utils";
import { getUserInfo, getTenantIdCommon } from "egov-ui-kit/utils/localStorageUtils";
 var batchcode=[];
// const localityt = async (action, state, dispatch) => {
//   alert("test1");
//   debugger;
//   let payload = await httpRequest(
//    "post",
//    "/egov-location/location/v11/boundarys/_search?hierarchyTypeCode=REVENUE&boundaryType=Block",
//    "_search",
//    [{ key: "tenantId", value: getTenantIdCommon() }],
//    {}
//  );
 
//   payload.TenantBoundary[0].boundary.forEach((element) => batchcode.push({code: element.code,  value: element.code}));
//   console.log("payload batchcode", batchcode);
 
//   // dispatch(
//   //        handleField(
//   //          "apply",
//   //          "components.div.children.wnsGenerateBill.children.locality",
//   //          "visible",
//   //          false
//   //        )
//   //      );
 
 
//  }
//  localityt();
export const createBill = getCommonCard({

subHeader: getCommonTitle({
    label: "Generate Bill"
  },
  {
    style: {
      marginBottom: 8
    }
  }
  ),
  wnsGenerateBill:  getCommonContainer ({

//  ---------------------------------------------------------------------------------------
//             Connection Type drop down
//-----------------------------------------------------------------------------------------
applicationtype: {
uiFramework: "custom-containers-local",
moduleName: "egov-wns",
componentPath: "AutosuggestContainer",
jsonPath: "generateBillScreen.transactionType",
props: {
  label: {
    labelName: "Connection Type",
    labelKey: "WS_GENERATE_BILL_CONNECTION_TYPE_LABEL"
  },
  labelPrefix: {
    moduleName: "TENANT",
    masterName: "TENANTS"
  },
  optionLabel: "name",
  placeholder: {
    labelName: "Connection Type",
    labelKey: "WS_GENERATE_BILL_CONNECTION_TYPE_PLACEHOLDER"
  },
  required: true,
  labelsFromLocalisation: true,
  data: [
    {
      code: "Water",
      value:"WS",
    },
    {
      code: "Sewerage",
      value:"SW",
    }
   
  ],
 
  className: "autocomplete-dropdown",
  jsonPath: "generateBillScreen.transactionType",
 
},
required: false,

gridDefination: {
  xs: 12,
  sm: 4
}
},
//  ---------------------------------------------------------------------------------------
//            Batch Type drop down
//-----------------------------------------------------------------------------------------

newCategory:{
  ...getSelectField({
 label: { labelName: "batch / locality", labelKey:"batch / locality"},
 placeholder: { labelName: "Select Batch", labelKey: "Batch" },
 gridDefination: { xs: 12, sm: 4 },
 data: [
   {
     code: "Locality",
     value:"LAS",
   },
   {
     code: "Batch",
     value:"BTCH",
   }
  
 ],
// sourceJsonPath: "applyScreenMdmsData.ws-services-masters.connectionCategory",
jsonPath: "generateBillScreen.batchType",
 errorMessage: "ERR_DEFAULT_INPUT_FIELD_MSG"
}),
beforeFieldChange: async (action, state, dispatch) => {
 let payload = await httpRequest(
  "post",
  "/egov-location/location/v11/boundarys/_search?hierarchyTypeCode=REVENUE&boundaryType=Block",
  "_search",
  [{ key: "tenantId", value: getTenantIdCommon() }],
  {}
);

 payload.TenantBoundary[0].boundary.forEach((element) => batchcode.push({code: element.code}));
 console.log("payload batchcode", batchcode);
 dispatch(prepareFinalObject(
  "applyScreenMdmsData.tenant.batchcode", 
  batchcode));
 

}

},
//---------------------------------------------------------------------------------------
//             locality drop down
//-----------------------------------------------------------------------------------------

locality: {
uiFramework: "custom-containers-local",
moduleName: "egov-wns",
componentPath: "AutosuggestContainer",
jsonPath: "generateBillScreen.mohallaData",
props: {
  label: { labelName: "Locality", labelKey:"Locality"},
  placeholder: { labelName: "Select maholla", labelKey: "WS_GENERATE_BILL_LOCALITY_PLACEHOLDER" },
  optionLabel: "name",
  required: false,
  labelsFromLocalisation: true,
   className: "autocomplete-dropdown",
  sourceJsonPath: "mohallaData",
  jsonPath: "generateBillScreen.mohallaData",

},
 required: false,
 gridDefination: {
  xs: 12,
  sm: 4
}
},

//---------------------------------------------------------------------------------------
//             locality drop down

// newbatCategory:{
//   ...getSelectField({
//  label: { labelName: "batch / locality", labelKey:"batch / locality"},
//  placeholder: { labelName: "Select Batch", labelKey: "Batch" },
//  gridDefination: { xs: 12, sm: 4 },
//  sourceJsonPath: "applyScreenMdmsData.tenant.batchcode",
//  jsonPath: "generateBillScreen.batchType",
//  errorMessage: "ERR_DEFAULT_INPUT_FIELD_MSG"
// }),
// afterFieldChange: async (action, state, dispatch) => {
//  // let ConectionCategory = await get(state, "screenConfiguration.preparedFinalObject.applyScreen.additionalDetails.connectionCategory");
//  // let connType = await get(state, "screenConfiguration.preparedFinalObject.applyScreen.connectionType");
//  let payload = await httpRequest(
//   "post",
//   "/egov-location/location/v11/boundarys/_search?hierarchyTypeCode=REVENUE&boundaryType=Block",
//   "_search",
//   [{ key: "tenantId", value: getTenantIdCommon() }],
//   {}
// );

//  payload.TenantBoundary[0].boundary.forEach((element) => batchcode.push({code: element.code,  key:element.code}));
//  console.log("payload batchcode", batchcode);

//  dispatch(
//         handleField(
//           "apply",
//           "components.div.children.wnsGenerateBill.children.locality",
//           "visible",
//           false
//         )
//       );


// }

// },
//-----------------------------------------------------------------------------------------
batch: {
  uiFramework: "custom-containers-local",
  moduleName: "egov-wns",
  componentPath: "AutosuggestContainer",
  jsonPath: "generateBillScreen.batchCod",
  props: {
    label: { labelName: "Batch", labelKey:"Batch"},
    placeholder: { labelName: "Select maholla", labelKey: "Batch" },
    optionLabel: "name",
    required: false,
    labelsFromLocalisation: true,
     className: "autocomplete-dropdown",
    sourceJsonPath: "applyScreenMdmsData.tenant.batchcode",
    jsonPath: "generateBillScreen.batchCod",
  
  },
   required: false,
   gridDefination: {
    xs: 12,
    sm: 4
  }
  },
 
     }),
  
        // }),
   
//---------------------------------------------------------------------------------------
//             Reset Button and Submit Button
//-----------------------------------------------------------------------------------------
  button: getCommonContainer({
    buttonContainer: getCommonContainer({
      resetButton: {
        componentPath: "Button",
        gridDefination: { xs: 12, sm: 4 },
        props: {
          variant: "outlined",
          style: {
            color: "rgba(0, 0, 0, 0.6000000238418579)",
            borderColor: "rgba(0, 0, 0, 0.6000000238418579)",
            width: "220px",
            height: "48px",
            margin: "28px",
            float: "right"
          }
        },
        children: { buttonLabel: getLabel({ labelKey: "WS_SEARCH_CONNECTION_SEARCH_BUTTON" }) },
        onClickDefination: {
          action: "condition",
          callBack: searchBillApiCall
        }
      },

//---------------------------------------------------------------------------------------
//             Generate Bill  Button
//-----------------------------------------------------------------------------------------
      searchButton: {
        componentPath: "Button",
        gridDefination: { xs: 12, sm: 4 },
        props: {
          variant: "contained",
          style: {
            color: "white",
            margin: "28px",
            backgroundColor: "rgba(0, 0, 0, 0.6000000238418579)",
            borderRadius: "2px",
            width: "220px",
            height: "48px",
            float: "left"
          }
        },
        children: { buttonLabel: getLabel({ labelKey: "WS_GENERATE_BILL_GENERATE_BUTTON" }) },
        onClickDefination: {
       
          action: "condition",
          callBack: generateBillApiCall
        }
      },
    })


  }),
  
  
});



