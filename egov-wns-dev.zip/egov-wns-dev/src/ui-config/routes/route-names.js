export const LANDING="/landing";
export const SCREEN_INTERFACE="/egov-ui-framework/:path?/:screenKey?/:hasRemoteConfig?";
export const PLAYGROUND="/ui-framework/playground";
export const REDIRECT="/egov-ui-framework/wns/home";
