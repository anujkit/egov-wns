export const SCREEN_INTERFACE="/egov-ui-framework/:path?/:screenKey?/:hasRemoteConfig?";
