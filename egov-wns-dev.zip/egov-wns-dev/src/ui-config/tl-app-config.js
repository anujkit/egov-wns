export const defaultLocation = { lat: 30.7333, lng: 76.7794 };
export const MAP_API_KEY = "AIzaSyCH9PmCbk_mcpgijAAlTeltC4deOxC5wEM";
