import React from "react";

const Asteric = () => {
  return <sup style={{ color: "#E54D42" }}>*</sup>;
};

export default Asteric;
