import React from "react";

const TestAtoms=()=>(<div>Test Atoms</div>)

export default TestAtoms;
