import React from "react";

const TestMolecules=()=>(<div>Test Molecules</div>)

export default TestMolecules;
